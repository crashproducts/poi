<?php
require_once 'single-tournament.php';
require_once 'helper-functions.php';