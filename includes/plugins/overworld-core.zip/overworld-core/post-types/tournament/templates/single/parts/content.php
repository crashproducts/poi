<div class="edgtf-tournament-single-content">
	<?php the_content(); ?>
</div>