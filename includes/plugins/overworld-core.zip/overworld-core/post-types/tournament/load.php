<?php
include_once OVERWORLD_CORE_CPT_PATH . '/tournament/tournament-register.php';
include_once OVERWORLD_CORE_CPT_PATH . '/tournament/helper-functions.php';