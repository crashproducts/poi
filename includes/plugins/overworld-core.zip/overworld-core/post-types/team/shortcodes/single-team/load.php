<?php
require_once 'single-team.php';
require_once 'helper-functions.php';