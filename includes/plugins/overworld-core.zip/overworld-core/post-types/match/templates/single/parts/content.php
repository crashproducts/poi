<div class="edgtf-match-content">
    <?php the_content(); ?>
</div>