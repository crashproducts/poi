<div class="edgtf-match-single-top-holder">
	<?php overworld_core_get_cpt_single_module_template_part('templates/single/parts/background', 'match', '', $params); ?>
</div>