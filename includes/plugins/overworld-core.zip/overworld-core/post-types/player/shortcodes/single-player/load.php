<?php
require_once 'single-player.php';
require_once 'helper-functions.php';