<?php

get_header();

overworld_edge_get_title();

do_action('overworld_edge_action_before_main_content');

overworld_core_get_single_player();

get_footer();