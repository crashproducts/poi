<div class="edgtf-comment-input-title">
	<label><?php esc_html_e( 'Title of your Review', 'overworld-core' ) ?></label>
	<input id="title" name="edgtf_comment_title" class="edgtf-input-field" type="text" />
</div>