<?php

require_once 'admin/reviews-map.php';
require_once 'reviews-functions.php';
require_once 'shortcodes/shortcodes-functions.php';